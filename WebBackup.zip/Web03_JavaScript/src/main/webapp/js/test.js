/**
 * 
 */
 document.write('<p>반가워요!</p>');
 document.write('<p>당신의 첫 번째 \"자바스크립트\"입니다.</p>');
 
 