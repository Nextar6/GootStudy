package edu.web.member;

public interface MemberDAO {
	public abstract int insert(MemberVO vo);

}
