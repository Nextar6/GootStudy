package edu.java.practice;

public class ArrayPractice {

	public static void main(String[] args) {
		String[] str = {"사과", "배", "바나나", "당근"};
			for(String s : str) {
				if(s == "배") {
					System.out.println(s + "찾았습니다");
				}
			}
			
		
	}

}
