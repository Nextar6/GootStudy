package edu.java.interface04;

// 인터페이스는 다른 인터페이스를 상속받는 것이 가능

public interface ParentInterface {
	public abstract void test1();


}
