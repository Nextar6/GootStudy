package edu.java.interface04;

class TestImple1 implements ParentInterface {
	@Override
	public void test1() {}
	
}
// 자식 인터페이스를 구현하는 클래스
class TestImple2 implements ParentInterface {
	@Override
	public void test1() {}
	public void test2() {}
}
public class InterfaceMain04 {

	public static void main(String[] args) {
		

	} // end main()

} // end InterfaceMain04
