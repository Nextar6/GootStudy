package edu.java.interface04;

public interface ChildInterface extends ParentInterface{
	public abstract void test2();

}
