package edu.java.interface06;

public interface RemoteController {
	public abstract void turnOn();
	public abstract void turnOff();
	

}
