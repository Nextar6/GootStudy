package edu.java.access05;

public class TestPublic {

} // end TestPublic

class Test2 {
	
}

class Test3 {
	
	
}

