package edu.java.inherit01;

public class SmartTv extends BasicTv{
	// 멤버 변수
	private String ip;
	// 생성자
	public SmartTv() {}
	
	// getter/ setter
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
} // end SmartTv
