package edu.java.inherit05;

public class Point {
	private double x; 
			double y;
			@Override
			public String toString() {
				return "Point [x=" + x + ", y=" + y + "]";
			}
			public Point(double x, double y) {
				super();
				this.x = x;
				this.y = y;
			}
		
	

}


