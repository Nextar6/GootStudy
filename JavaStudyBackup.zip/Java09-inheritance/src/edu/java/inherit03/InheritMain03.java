package edu.java.inherit03;

public class InheritMain03 {

	public static void main(String[] args) {
//		Phone phone1 = new Phone();  기본생성자 호출
		
		SmartPhone phone2 = new SmartPhone("010-111-1111");
		
		
	} // end main()

} // Inherit03
