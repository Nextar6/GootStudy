package codeup;


public class Main {
	
	public static void main(String[] args) {
		float x;
		x = (float) 1.414213;
		System.out.println(x);
	}

}
