package edu.java.review04;

import java.util.Scanner;

public class Review04day {

	public static void main(String[] args) {
	
		int count = 0;
		while (count > 0) {
			System.out.println(count);
			count--;
		}
			
		do { System.out.println(count);
		count--;
		} while(count >0);

	} // end main()
	
} // end Review04day

