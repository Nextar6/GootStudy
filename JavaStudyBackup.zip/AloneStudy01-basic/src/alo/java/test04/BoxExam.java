package alo.java.test04;

public class BoxExam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
