package alo.java.test04;

import java.util.Date;
import java.util.Scanner;

public class DateExam {

	public static void main(String[] args) {
	float x;
	Scanner sc =new Scanner(System.in);
	x = sc.nextFloat();
	System.out.printf("%f",x);
	
	} // end main()

} // End DateExam
