package alo.java.test03;

public interface Menu {
	public static final int QUITE = 0;
	public static final int INSERT = 1;
	public static final int SELECT_ALL = 2;
	public static final int SELECT_BY_INDEX = 3;
	public static final int UPDATE = 4 ;

}
