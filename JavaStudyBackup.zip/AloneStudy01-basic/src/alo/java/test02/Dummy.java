package alo.java.test02;

public class Dummy implements DataBaseQ{

	@Override
	public int insert(String id, String pw) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
