package alo.java.test02;

public interface DataBaseQ {
	public static final int DATABASE_VERSION = 1;
	public abstract int insert(String id, String pw);

}
