package alo.java.test02;

public interface RemoteCon {
	public abstract void trunOn();
	public abstract void trunOff();
	
	

}
