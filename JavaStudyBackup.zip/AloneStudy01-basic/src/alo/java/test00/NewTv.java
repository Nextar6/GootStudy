package alo.java.test00;

public class NewTv extends BaseTv{
	String ip;
	
	public NewTv() {}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}
	
	

}
