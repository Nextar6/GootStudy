package alo.java.test00;

public class BaseTv {
	boolean powerOn;
	int volume;
	int chennel;
	
	public BaseTv() {}
	
	public void turnOnOff() {
		System.out.println("부모 객체 호출합니다");
	}
	

}
