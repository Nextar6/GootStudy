package alo.java.basic01;

public class SportsCar extends Car{
	
	@Override
	public void speedUp() {
		speed += 10;
	}
	public void stop() {
		System.out.println();
	}
}
