package alo.java.basic01;

public class Student {

}
