package alo.java.basic01;

public class KoreanExam {

	public static void main(String[] args) {
		Korean k1 = new Korean("박자바", "010200410");
		System.out.println(k1.name+ "," + k1.nation + "," +k1.ssn);
	
	} // main()
} // end score
