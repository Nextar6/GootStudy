package alo.java.basic01;

public enum Week {
	MONDAY,
	TUESDAY,
	WEDNSDAY,
	TUHRSDAY,
	FRIDAY,
	SATURDAY,
	SUNDAY

	

}
