package alo.java.basic01;

public class Calculator {
	double areaRactangle(double width) {
		return width * width;
	}
	double areaRactangle(double width, double height) {
		return width*height;
	}

}

