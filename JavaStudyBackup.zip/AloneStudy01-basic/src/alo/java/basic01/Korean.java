package alo.java.basic01;

public class Korean {
	String nation = "대한민국";
	String name;
	String ssn;
	
	public Korean(String name, String ssn) {
		this.name = name;
		this.name =ssn;
	}
	
		
	
	
}
