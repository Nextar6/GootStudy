package alo.java.exam;

public class StuExam {

	public static void main(String[] args) {
		Student student = new Student("홍길동", "123-321", 1);
		System.out.println(student.name);
		System.out.println(student.ssn);
		System.out.println(student.studentNo);

	}

}
