package alo.java.exam;

public class PrintPoint {

	public static void main(String[] args) {
		Point p1 = new Point(1.0, 2.0);
		System.out.println(p1);
		Person person = new Person("떵개");
		System.out.println(person);
		
		
	
	}

}
