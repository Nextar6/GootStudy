package alo.java.exam;

public final class Member {

}
