package alo.java.exam;

public class veryimportantPerson {

}
