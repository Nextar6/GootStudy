package alo.java.exam;

public class People {
	public String name;
	public String ssn;
	
	
	public People(String name, String ssn) {
		this.name = name;
		this.ssn = ssn;
		System.out.println("부모 객체 생성완료.");
		
	}

}
