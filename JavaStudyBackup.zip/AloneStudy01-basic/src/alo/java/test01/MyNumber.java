package alo.java.test01;

public class MyNumber {
	
	

}
