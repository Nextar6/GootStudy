package alo.java.test01;

public class Tvmain01 {

	public static void main(String[] args) {
		BasicTv tv = new BasicTv();
		tv.channelUp();
		tv.turnOnOff();
		tv.disPlay();
		tv.turnOnOff();
		tv.volumeUp();
		tv.disPlay();

	}

}
