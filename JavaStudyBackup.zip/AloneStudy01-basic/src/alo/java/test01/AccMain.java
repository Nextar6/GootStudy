package alo.java.test01;

public class AccMain {

	public static void main(String[] args) {
	
	}// end main()

} // end Conmain
