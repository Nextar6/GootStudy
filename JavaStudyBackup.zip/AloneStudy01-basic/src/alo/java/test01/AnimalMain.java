package alo.java.test01;

public class AnimalMain {

	public static void main(String[] args) {
		Animal ani = new Animal();
		ani.speak();
		Dog dog = new Dog("믹스","재재");
		dog.speak();
		Cat cat = new Cat();
		cat.speak();
		
		

	}

}
