package alo.java.test01;

public class Animal {

	private String name;

	public Animal() {}
	
	public Animal(String name) {
		this.name = name;
	}
	public void speak() {
	System.out.println("짖어 댑니다.");
	}

} // End Animal
