package alon.java.testgui;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double x = sc.nextDouble();
		
		
			System.out.printf("%n%f", x);

	}

}

